This file was too large for one zip part, so it was cut into raw pieces:
  notes\readme.txt
Pieces: 7  (stored in notes_part02.zip .. notes_part08.zip)

Easiest: open AgentParcel, choose "Rebuild from parts" and drop the parts in.
By hand:
1) Extract ALL the part zips into the same folder.
2) Open Command Prompt (cmd.exe) in that folder and run:

copy /b "notes\readme.txt.001"+"notes\readme.txt.002"+"notes\readme.txt.003"+"notes\readme.txt.004"+"notes\readme.txt.005"+"notes\readme.txt.006"+"notes\readme.txt.007" "notes\readme.txt"

3) After checking the rebuilt file, the .### piece files can be deleted.
